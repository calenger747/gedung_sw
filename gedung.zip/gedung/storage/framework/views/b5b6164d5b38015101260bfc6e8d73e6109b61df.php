<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.headers.cards', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="container-fluid mt--9">
    <div class="row ">
        <div class="col-md-12">
            <div class="card shadow">
                <div class="card-header border-0">
                    <div class="row align-items-center">
                        <div class="col-12">
                            <h3 class="mb-0"><?php echo e(__('Data Gedung')); ?></h3>
                        </div>
                    </div>
                </div>
                <?php $__currentLoopData = $gedung; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gdg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-12" id="detail_gedung">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-5">
                                <input type="hidden" name="id_gedung" id="id_gedung" value="<?php echo e($gdg->id_gedung); ?>">
                                <div class="col-md-12 text-center">
                                    <img src="<?php echo e(url('/data_file/'.$gdg->gambar)); ?>" width="50%" height="50%" class="img">
                                </div>
                            </div>
                            <div class="col-md-7">
                                <table class="table table-borderless" width="100%">
                                    <thead>
                                        <tr>
                                            <th>Nama Gedung</th>
                                            <th><?php echo e($gdg->nama_gedung); ?></th>
                                        </tr>
                                        <tr>
                                            <th>Alamat<br><br><br></th>
                                            <th><?php echo e($gdg->alamat); ?>, <br> <?php echo e($gdg->name_kel); ?>, <br> <?php echo e($gdg->name_kec); ?>, <br> <?php echo e($gdg->name_kab); ?>, <br> <?php echo e($gdg->name_prov); ?> - <?php echo e($gdg->kode_pos); ?></th>
                                        </tr>
                                        <tr>
                                            <th>Koordinat</th>
                                            <th><?php echo e($gdg->koordinat); ?></th>
                                        </tr>
                                        <tr>
                                            <th>Contact</th>
                                            <th><?php echo e($gdg->nama_kontak); ?> - <?php echo e($gdg->kontak); ?></th>
                                        </tr>
                                        <tr>
                                            <th>Jam Operasional</th>
                                            <th><?php echo e($gdg->jam_buka); ?> - <?php echo e($gdg->jam_tutup); ?></th>
                                        </tr>
                                        <tr>
                                            <th>Kunci</th>
                                            <th><?php echo e($gdg->kunci); ?></th>
                                        </tr>
                                    </thead>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div></br>
    <div class="row">
        <div class="col-md-6">
            <div class="card shadow">
                <div class="card-header border-0">
                    <div class="row align-items-center">
                        <div class="col-12">
                            <h3 class="mb-0"><?php echo e(__('Lantai')); ?></h3>
                        </div>
                    </div>
                </div>
                <?php $__currentLoopData = $lantai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-12" id="detail_lantai">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-12">
                                <input type="hidden" name="id_lantai" id="id_lantai" value="<?php echo e($lt->id_lantai); ?>">
                                <div class="col-md-12 text-center" id="nama_lantai">
                                    <h1>Lantai "<?php echo e($lt->nama_lantai); ?>"</h1>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card shadow">
                <div class="card-header border-0">
                    <div class="row align-items-center">
                        <div class="col-12">
                            <h3 class="mb-0"><?php echo e(__('Rak')); ?></h3>
                        </div>
                    </div>
                </div>
                <?php $__currentLoopData = $rak; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-12" id="detail_rak">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-12">
                                <input type="hidden" name="id_rak" id="id_rak" value="<?php echo e($r->id_rak); ?>">
                                <div class="col-md-12 text-center" id="nama_rak">
                                    <h1>Rak "<?php echo e($r->nama_rak); ?>"</h1>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div></br>
    <div class="row">
        <div class="col-md-12">
            <div class="card shadow">
                <div class="card-header border-0">
                    <div class="row align-items-center">
                        <div class="col-12">
                            <h3 class="mb-0"><?php echo e(__('Data Perangkat')); ?></h3>
                        </div>
                    </div>
                </div>
                <?php $__currentLoopData = $perangkat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-12" id="detail_perangkat">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-12">
                                <input type="hidden" name="id_perangkat" id="id_perangkat" value="<?php echo e($pr->id_perangkat); ?>">
                                <div class="col-md-12 text-center" id="nama_rak">
                                    <h1>Perangkat "<?php echo e($pr->nama); ?> - <?php echo e($pr->nama_perangkat); ?>"</h1>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="table-responsive">
                    <table class="table align-items-center table-flush" width="100%">
                        <thead class="thead-light">
                            <tr>
                                <th scope="col" width="30%"><?php echo e(__('Nama Port')); ?></th>
                                <th scope="col" width="70%"><?php echo e(__('Keterangan')); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $port; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($p->nama_port); ?></td>
                                <td><?php echo e($p->keterangan); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <div class="card-footer py-4">
                    <nav class="d-flex justify-content-end" aria-label="...">
                        <?php echo e($port->links()); ?>

                    </nav>
                </div>
                <div class="modal-footer">
                    <?php $__currentLoopData = $gedung; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gdg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $lantai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $__currentLoopData = $rak; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php $__currentLoopData = $perangkat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a href="/user/print/<?php echo e($gdg->id_gedung); ?>/<?php echo e($lt->id_lantai); ?>/<?php echo e($r->id_rak); ?>/<?php echo e($pr->id_perangkat); ?>" target="_blank">
                                    <btn class="btn btn-primary">Print</btn>
                                </a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
    <?php echo $__env->make('layouts.footers.auth', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>