<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.headers.cards', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="container-fluid mt--7">
    <div class="row">
        <div class="col">
            <div class="card shadow">
                <div class="card-header border-0">
                    <div class="row align-items-center">
                        <div class="col-8">
                            <h3 class="mb-0"><?php echo e(__('Data Rak')); ?></h3>
                        </div>
                        <div class="col-4 text-right">
                            <a href="#" data-toggle="modal" data-target="#modalAdd" class="btn btn-sm btn-primary"><?php echo e(__('Add rak')); ?></a>
                        </div>
                    </div>
                </div>
                <div class="col-12">
                    <?php if(session('status')): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <?php echo e(session('status')); ?>

                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <?php endif; ?>
                </div>
                <div class="table-responsive">
                    <table class="table align-items-center table-flush">
                        <thead class="thead-light">
                            <tr>
                                <th scope="col"><?php echo e(__('Nama Gedung')); ?></th>
                                <th scope="col"><?php echo e(__('Nama Lantai')); ?></th>
                                <th scope="col"><?php echo e(__('Nama Rak')); ?></th>
                                <th scope="col"><?php echo e(__('Updated At')); ?></th>
                                <th scope="col"></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $rak; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($r->nama_gedung); ?></td>
                                <td><?php echo e($r->nama_lantai); ?></td>
                                <td><?php echo e($r->nama_rak); ?></td>
                                <td><?php echo e($r->updated_at); ?></td>
                                <td class="text-right">
                                    <div class="dropdown">
                                        <a class="btn btn-sm btn-icon-only text-light" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                            <i class="fas fa-ellipsis-v"></i>
                                        </a>
                                        <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                                            <a class="dropdown-item" data-toggle="modal" data-target="#modalEdit<?php echo e($r->id_rak); ?>" href="#"><?php echo e(__('Edit')); ?></a>
                                            <a class="dropdown-item" data-toggle="modal" data-target="#modalDelete<?php echo e($r->id_rak); ?>" href="/admin/gedung/delete/<?php echo e($r->id_rak); ?>"><?php echo e(__('Delete')); ?></a>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <div class="card-footer py-4">
                    <nav class="d-flex justify-content-end" aria-label="...">
                        <?php echo e($rak->links()); ?>

                    </nav>
                </div>
            </div>
        </div>
    </div>
    <?php echo $__env->make('layouts.footers.auth', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>
<!-- Modal Add -->
<div class="modal fade" id="modalAdd" tabindex="-1" role="dialog" aria-labelledby="searchModal" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <div class="panel-title">
                    <h4>Tambah Rak</h4>
                </div>
                <button aria-hidden="true" data-dismiss="modal" class="close right" type="button">×</button>
            </div>
            <div class="modal-body">
                <form method="post" action="/admin/rak/store" autocomplete="off">
                    <?php echo csrf_field(); ?>
                    <div class="pl-lg-1">
                        <div class="form-group">
                            <label class="form-control-label" for="input-name"><?php echo e(__('Nama Gedung')); ?></label>
                            <select class="form-control" name="nama_gedung" id="gedung" required="">
                                <option value="" disable="true" selected="true">Pilih Gedung</option>
                                <?php $__currentLoopData = $gedung; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($value->id_gedung); ?>"><?php echo e($value->nama_gedung); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label class="form-control-label" for="input-lantai"><?php echo e(__('Nama Lantai')); ?></label>
                            <select class="form-control" name="nama_lantai" id="lantai" required="">
                                <option value="" disable="true" selected="true">Pilih Lantai</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label class="form-control-label" for="input-lantai"><?php echo e(__('Nama Rak')); ?></label>
                            <input type="text" name="nama_rak" id="input-lantai" class="form-control form-control-alternative" placeholder="<?php echo e(__('Nama Rak')); ?>" value="" required>
                        </div>
                        <div class="text-center">
                            <button type="submit" class="btn btn-success mt-4"><?php echo e(__('Save')); ?></button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__currentLoopData = $rak; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<!-- Modal Edit -->
<div class="modal fade" id="modalEdit<?php echo e($r->id_rak); ?>" tabindex="-1" role="dialog" aria-labelledby="searchModal" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <div class="panel-title">
                    <h4>Edit Rak</h4>
                </div>
                <button aria-hidden="true" data-dismiss="modal" class="close right" type="button">×</button>
            </div>
            <div class="modal-body">
                <form method="post" action="/admin/rak/update/<?php echo e($r->id_rak); ?>" autocomplete="off">
                    <?php echo csrf_field(); ?>
                    <div class="pl-lg-1">
                        <div class="form-group">
                            <label class="form-control-label" for="input-name"><?php echo e(__('Nama Gedung')); ?></label>
                            <select class="form-control" name="nama_gedung" id="gedung1<?php echo e($r->id_rak); ?>" required="">
                                <option value="" disable="true" selected="true">Pilih Gedung</option>
                                <?php $__currentLoopData = $gedung; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($value->id_gedung == $r->id_gedung): ?>
                                        <option value="<?php echo e($value->id_gedung); ?>" selected=""><?php echo e($value->nama_gedung); ?></option>
                                    <?php else: ?>
                                        <option value="<?php echo e($value->id_gedung); ?>"><?php echo e($value->nama_gedung); ?></option>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label class="form-control-label" for="input-lantai"><?php echo e(__('Nama Lantai')); ?></label>
                            <select class="form-control" name="nama_lantai" id="lantai1<?php echo e($r->id_rak); ?>" required="">
                                <option value="" disable="true" selected="true">Pilih Lantai</option>
                                <?php $__currentLoopData = $lantai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($value->id_lantai == $r->id_lantai): ?>
                                        <option value="<?php echo e($value->id_lantai); ?>" selected=""><?php echo e($value->nama_lantai); ?></option>
                                    <?php elseif($value->id_lantai != $r->id_lantai && $value->id_gedung == $r->id_gedung): ?>
                                        <option value="<?php echo e($value->id_lantai); ?>"><?php echo e($value->nama_lantai); ?></option>
                                    <?php else: ?>
                                        <option value="<?php echo e($value->id_lantai); ?>" style="display: none;" disabled=""><?php echo e($value->nama_lantai); ?></option>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label class="form-control-label" for="input-lantai"><?php echo e(__('Nama Rak')); ?></label>
                            <input type="text" name="nama_rak" id="input-lantai" class="form-control form-control-alternative" placeholder="<?php echo e(__('Nama Rak')); ?>" value="<?php echo e($r->nama_rak); ?>" required>
                        </div>
                        <div class="text-center">
                            <button type="submit" class="btn btn-success mt-4"><?php echo e(__('Save')); ?></button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__currentLoopData = $rak; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<!-- Modal Delete -->
<div class="modal fade" id="modalDelete<?php echo e($r->id_rak); ?>" tabindex="-1" role="dialog" aria-labelledby="searchModal" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <div class="panel-title">
                    <h4>Hapus Rak</h4>
                </div>
                <button aria-hidden="true" data-dismiss="modal" class="close right" type="button">×</button>
            </div>
            <div class="modal-body">
                <form method="post" action="/admin/rak/delete/<?php echo e($r->id_rak); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="form-group text-center">
                        <label>Apakah Anda Yakin Untuk Menghapus Data Ini ?</label>
                    </div>
                    <div class="form-group text-center">
                        <label>Menghapus Data Ini Juga Akan Menghapus Data Perangkat, Dan Port Yang Berkaitan Dengan Data Ini.</label>
                    </div>
                    <div class="form-group text-center">
                        <input type="submit" class="btn btn-success" value="Ya">
                        <button aria-hidden="true" class="btn btn-primary" data-dismiss="modal" class="close right" type="button">Tidak</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<?php $__currentLoopData = $rak; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<script type="text/javascript">
//Tambah
$('#gedung').on('change', function(e) {
    console.log(e);
    var id_gedung = e.target.value;
    $.get('/json-lantai?id_gedung=' + id_gedung, function(data) {
        console.log(data);
        $('#lantai').empty();
        $('#lantai').append('<option value="" disable="true" selected="true">Pilih Lantai</option>');

        $.each(data, function(index, lantaiObj) {
            $('#lantai').append('<option value="' + lantaiObj.id_lantai + '">' + lantaiObj.nama_lantai + '</option>');
        })
    });
});

//Edit
$('#gedung1<?php echo e($r->id_rak); ?>').on('change', function(e) {
    console.log(e);
    var id_gedung = e.target.value;
    $.get('/json-lantai?id_gedung=' + id_gedung, function(data) {
        console.log(data);
        $('#lantai1<?php echo e($r->id_rak); ?>').empty();
        $('#lantai1<?php echo e($r->id_rak); ?>').append('<option value="" disable="true" selected="true">Pilih Lantai</option>');

        $.each(data, function(index, lantai) {
            $('#lantai1<?php echo e($r->id_rak); ?>').append('<option value="' + lantai.id_lantai + '">' + lantai.nama_lantai + '</option>');
        })
    });
});

</script>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>