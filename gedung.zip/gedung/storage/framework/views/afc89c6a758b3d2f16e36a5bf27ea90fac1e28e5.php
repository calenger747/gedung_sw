<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('layouts.headers.cards', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="container-fluid mt--7">
        <div class="row">
            <div class="col">
                <div class="card shadow">
                    <div class="card-header border-0">
                        <div class="row align-items-center">
                            <div class="col-12">
                                <h3 class="mb-0"><?php echo e(__('Data Gedung')); ?></h3>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-12">
                        <?php if(session('status')): ?>
                            <div class="alert alert-success alert-dismissible fade show" role="alert">
                                <?php echo e(session('status')); ?>

                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                        <?php endif; ?>
                    </div>

                    <div class="table-responsive">
                        <table class="table align-items-center table-flush">
                            <thead class="thead-light">
                                <tr>
                                    <th scope="col"><?php echo e(__('Name')); ?></th>
                                    <th scope="col"><?php echo e(__('Kota')); ?></th>
                                    <th scope="col"><?php echo e(__('Kontak')); ?></th>
                                    <th scope="col"><?php echo e(__('Jam Operasional')); ?></th>
                                    <th scope="col"><?php echo e(__('Kunci')); ?></th>
                                    <th scope="col"><?php echo e(__('Updated At')); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $gedung; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gdg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($gdg->nama_gedung); ?></td>
                                        <td><?php echo e($gdg->name_kab); ?></td>
                                        <td><?php echo e($gdg->kontak); ?></td>
                                        <td><?php echo e($gdg->jam_buka); ?> - <?php echo e($gdg->jam_tutup); ?></td>
                                        <td><?php echo e($gdg->kunci); ?></td>
                                        <td><?php echo e($gdg->updated_at); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="card-footer py-4">
                        <nav class="d-flex justify-content-end" aria-label="...">
                            <?php echo e($gedung->links()); ?>

                        </nav>
                    </div>
                </div>
            </div>
        </div>

        <?php echo $__env->make('layouts.footers.auth', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script type="text/javascript">
$(".gambar").change(function() {
    if (this.files && this.files[0] && this.files[0].name.match(/\.(jpg|png)$/)) {
        if (this.files[0].size > 8048576) {
            $('.logo').val('');
            alert('Batas Maximal Ukuran File 8MB !');
        } else {
            var reader = new FileReader();
            reader.readAsDataURL(this.files[0]);
        }
    } else {
        $('.gambar').val('');
        alert('Hanya File jpg/png Yang Diizinkan !');
    };
});

$(document).ready(function() {
    $('#example').DataTable();
} );

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>