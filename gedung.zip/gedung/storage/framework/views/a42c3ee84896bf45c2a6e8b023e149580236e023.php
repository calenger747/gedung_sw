<footer class="footer">
    <?php echo $__env->make('layouts.footers.nav', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</footer>